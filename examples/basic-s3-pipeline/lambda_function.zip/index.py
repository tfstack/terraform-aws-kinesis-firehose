import json
import base64

def handler(event, context):
    output = []

    for record in event['records']:
        try:
            # Debug: log what we're receiving
            print(f"Processing record {record['recordId']}")
            print(f"Data type: {type(record['data'])}")
            print(f"Data content: {repr(record['data'])}")

            # Decode the base64 data first
            payload = base64.b64decode(record['data'])
            print(f"Decoded payload: {payload.decode('utf-8')}")

            # Parse the decoded JSON
            original_data = json.loads(payload.decode('utf-8'))

            # Process the data (example: add timestamp)
            processed_data = {
                'original_data': original_data,
                'processed_at': context.aws_request_id,
                'processing_timestamp': context.aws_request_id
            }

            # Encode the processed data
            encoded_data = base64.b64encode(json.dumps(processed_data).encode('utf-8')).decode('utf-8')

            output.append({
                'recordId': record['recordId'],
                'result': 'Ok',
                'data': encoded_data
            })

        except Exception as e:
            print(f"[ERROR] Processing record {record['recordId']}: {str(e)}")
            # Return the record as failed
            output.append({
                'recordId': record['recordId'],
                'result': 'ProcessingFailed',
                'data': record['data']  # Return original data
            })

    return {'records': output}
