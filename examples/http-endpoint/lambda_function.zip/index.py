import json
import base64

def handler(event, context):
    output = []

    for record in event['records']:
        # Decode the data
        payload = base64.b64decode(record['data'])

        # Process the data (example: add metadata)
        processed_data = {
            'original_data': json.loads(payload.decode('utf-8')),
            'processed_at': context.aws_request_id,
            'source': 'kinesis-firehose'
        }

        # Encode the processed data
        encoded_data = base64.b64encode(json.dumps(processed_data).encode('utf-8')).decode('utf-8')

        output.append({
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': encoded_data
        })

    return {'records': output}
